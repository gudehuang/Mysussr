#!/system/bin/sh
echo "==SuSSR v4.3.1=="
echo "===by supppig==="
getbackstring()
{
[ -z "$ss" ] && str=$($1) || str=$ss && ss=""
f="0" && re=""
for x in $str
do
 if [ "$f" = "0" ];then
  f="0" && [ "$x" = "$2" ] && f="1"
 else
  ff="1" && for xx in $3;do [ $x = $xx ] && ff="0";done
  if [ "$ff" = "1" ];then
  [ -z "$re" ] && re=$x || re=$re" "$x
  fi
  f="0"
 fi
done
[ -z "$re" ] && re=$4
}

findstring()
{
iptables -t $1 | grep -q "$2" && re="$3" || re="$4"
[ "$5" = "y" ] && echo "$re"
}

findstringbyss()
{
if [ "$ss" = "" ];then
re="$2"
else
re="$1"
fi
ss=""
[ "$3" = "y" ] && echo "$re"
}

cd "${0%/*}"
. ./setting.ini
if [ "$pbq" = "1" ];then
ps|grep -qE ss-redir-video?$&&echo -n "✔ss-redir(破版权)"||echo "✘ss-redir(破版权)"
else
ps|grep -qE ss-redir?$&&echo -n "✔ss-redir "||echo -n "✘ss-redir"
fi
ps|grep -q pdnsd$&&echo "✔pdnsd  "||echo "✘pdnsd"

ss=$(iptables -t mangle -S SSR_UDP_PRE | grep 'on-port' | grep 1250)
findstringbyss "y" "n"
if [ "$re" = "y" ];then
ps|grep -q redsocks2$&&echo -n "✔redsocks2  "||echo -n "✘redsocks2  "
ps|grep -qE gost?$&&echo -n "✔gost  "||echo -n "✘gost  "
ps|grep -qE ss-local?$&&echo "✔ss-local  "||echo "✘ss-local  "
fi
echo ""

if [ "$jxjg" != "" ];then
echo "=====域名转IP====="
echo -e "$jxjg"
fi

echo "===iptables链检测==="
findstring "nat -S PREROUTING" "ssr_nat_PRE" "✔nat_PRE" "✘nat_PRE"
allre=$re
findstring "nat -S OUTPUT" "ssr_nat_OUT" "✔nat_OUT" "✘nat_OUT"
allre=$allre" "$re
echo "nat表: "$allre

if [ "$dludp" = "1" -o "$dludp" = "2" ];then
findstring "mangle -S SSR_UDP_PRE" "SSR_UDP_LAN" "✔UDP_LAN" "✘UDP_LAN"
allre=$re
findstring "mangle -S PREROUTING" "SSR_UDP_PRE" "✔UDP_PRE" "✘UDP_PRE"
allre=$allre" "$re
findstring "mangle -S OUTPUT" "SSR_UDP_OUT" "✔UDP_OUT" "✘UDP_OUT"
allre=$allre" "$re
echo "mangle表: "$allre
fi
echo ""

#防熊孩子没开脚本时运行检测，反馈说UDP没清理干净。
findstring "nat -S ssr_nat_OUT" "ACCEPT" "y" "n"
if [ "$re" = "y" ];then

echo "====UDP转发设置===="
ss=$(iptables -t nat -S ssr_nat_OUT | grep udp | grep 65535 | grep -v owner)
findstringbyss "本机UDP：✘ 禁网" "本机UDP：✔ 联网" "y"
ss=$(iptables -t nat -S ssr_nat_PRE | grep udp | grep 65535)
findstringbyss "热点UDP：✘ 禁网" "热点UDP：✔ 联网" "y"

getbackstring "iptables -t mangle -S SSR_UDP_PRE" "--on-port" "" "888"
case $re in
888)
 echo "UDP代理方式：不转发(直连)"
 jx="n"
 ;;
1230)
 echo -n "UDP代理方式：UDP转发"
 ;;
1231)
 echo -n "UDP代理方式：UDP转发(自定义端口)"
 ;;
1250)
 echo -n "UDP代理方式：通过TCP转发"
 ;;
*)
 echo "UDP代理方式：检测失败！"
 jx="n"
 ;;
esac

if [ "$jx" != "n" ];then
ss=$(iptables -t mangle -S SSR_UDP_OUT | grep -v owner | grep 6688)
findstringbyss "（全局）" "（局部）" "y"

re=$(echo $re | grep 全)
if [ "$re" = "" ];then
ss=$(iptables -t mangle -S SSR_UDP_OUT | grep owner | grep 6688)
getbackstring "" "--uid-owner" "0 3004" "未设置(设置不合理)"
echo "代理UDP应用：$re"
else
ss=$(iptables -t mangle -S SSR_UDP_OUT | grep owner | grep ACCEPT)
getbackstring "" "--uid-owner" "0 3004" "未设置"
echo "不代理UDP应用：$re"
fi
fi

echo ""

echo "====应用单独设置===="
ss=$(iptables -t nat -S ssr_nat_OUT | grep tcp | grep ACCEPT)
getbackstring "" "--uid-owner" "" "未设置"
echo "TCP放行UID：$re"
ss=$(iptables -t nat -S ssr_nat_OUT | grep udp | grep ACCEPT)
getbackstring "" "--uid-owner" "" "未设置"
echo "UDP放行UID：$re"
ss=$(iptables -t nat -S ssr_nat_OUT | grep udp | grep 65535)
getbackstring "" "--uid-owner" "" "未设置"
echo "UDP禁网UID：$re"
echo ""

echo ✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄
echo ""
echo ✺ nat表 ssr_nat_OUT链:
iptables -t nat -S ssr_nat_OUT

echo ""
echo ✺ nat表 ssr_nat_PRE链:
iptables -t nat -S ssr_nat_PRE

if [ "$dludp" = "1" -o "$dludp" = "2" ];then
echo ""
echo ✺ mangle表 SSR_UDP_LAN链:
iptables -t mangle -S SSR_UDP_LAN

echo ""
echo ✺ mangle表 SSR_UDP_OUT链:
iptables -t mangle -S SSR_UDP_OUT

echo ""
echo ✺ mangle表 SSR_UDP_PER链:
iptables -t mangle -S SSR_UDP_PRE
fi

else
 echo "提示：脚本已关闭，正常情况下，以上检测结果应该全部是✘。"
fi
