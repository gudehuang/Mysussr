#!/system/bin/sh
 
################
#KP规则更新脚本#
#  by supppig  #
################
 
wgetdown()
{
output=$1
url1=$2
${bbx} rm -f $output
${bbx} wget -q -T10 -O $output $url1
if [ "$?" != "0" ] || [ ! -s "$output" ] ; then
	${bbx} rm -f $output
fi
if [ -s "$output" ] ; then
    ${bbx} chmod 777 $output
fi
}
checkdownload()
{
if [ ! -s "$predown/koolproxy.txt" ];then
${bbx} rm -rf $predown
echo "静态规则下载失败！退出！"
exit 1
fi
if [ ! -s "$predown/1.dat" ];then
${bbx} rm -rf $predown
echo "视频规则下载失败！退出！"
exit 1
fi
}
md5update()
{
old_md5=`${bmd5sum} $kpdir/koolproxy.txt | ${bcut} -d' ' -f1`
new_md5=`${bmd5sum} $predown/koolproxy.txt | ${bcut} -d' ' -f1`
old_md5=${old_md5:0:6}
new_md5=${new_md5:0:6}
if [ "$old_md5" != "$new_md5" ] ; then
echo "静态规则有更新！($old_md5-->$new_md5)"
jtgx="y"
else
echo "静态规则没有更新($old_md5)"
fi
old_md5=`${bmd5sum} $kpdir/1.dat | ${bcut} -d ' ' -f1`
new_md5=`${bmd5sum} $predown/1.dat | ${bcut} -d ' ' -f1`
old_md5=${old_md5:0:6}
new_md5=${new_md5:0:6}
if [ "$old_md5" != "$new_md5" ] ; then
echo "视频规则有更新！($old_md5-->$new_md5)"
spgx="y"
else
echo "视频规则没有更新($old_md5)"
fi
}
printkpinfo()
{
str=$(${bgrep} '^!x.*rules' $kpdir/koolproxy.txt | ${bcut} -d' ' -f5-6)
echo "静态规则更新日期：$str"
str=$(${bgrep} '^!x.*video' $kpdir/koolproxy.txt | ${bcut} -d' ' -f5-6)
echo "视频规则更新日期：$str"
str=$(${bgrep} '^!x.*rules' $kpdir/koolproxy.txt | ${bcut} -d' ' -f9-)
echo "KoolProxy规则作者：$str"
}
killkp()
{
echo "关闭KoolProxy
"
${bbx} killall -q koolproxy
}
echo "
==KoolProxy规则更新脚本==
=====  by supppig  ====
"
DIR="${0%/*}"
workdir=${DIR}'/tools'
kpdir=${workdir}'/KoolProxy'
bbx=${DIR}'/tools/busybox'
bgrep="${bbx} grep"
bcut="${bbx} cut"
bmd5sum="${bbx} md5sum"
predown=$workdir/pre_download
${bbx} mount -o rw,remount /system 2>&-
${bbx} mount -o rw,remount /data 2>&-
cd $DIR
${bbx} rm -rf $predown
${bbx} mkdir $predown
spurl="http://entware.mirrors.ligux.com/koolproxy/1.dat"
jturl="http://entware.mirrors.ligux.com/koolproxy/koolproxy.txt"
echo "下载规则。。。
"
wgetdown "$predown/koolproxy.txt" $jturl
wgetdown "$predown/1.dat" $spurl
checkdownload
echo "启动md5校检更新模式。。。"
echo ""
md5update
echo ""
if [ "$jtgx" != "y" -a "$spgx" != "y" ];then
printkpinfo
echo "
KoolProxy规则不需更新。程序退出。"
${bbx} rm -rf $predown
exit 0
fi
killkp
if [ "$jtgx" = "y" ];then
echo "正在替换静态规则文件。。。"
${bbx} rm -f "$kpdir/koolproxy.txt"
${bbx} cp -f "$predown/koolproxy.txt" "$kpdir/koolproxy.txt"
fi
if [ "$spgx" = "y" ];then
echo "正在替换视频规则文件。。。"
${bbx} rm -f "$kpdir/1.dat"
${bbx} cp -f "$predown/1.dat" "$kpdir/1.dat"
fi
echo "
重启KoolProxy
"
$kpdir/koolproxy -c2 -b $kpdir -d >/dev/null &
printkpinfo
${bbx} rm -rf $predown
echo "
KoolProxy更新完毕！"
exit 0
