#!/system/bin/sh

############
#  SuSSR   #
# ver4.3.1 #
#By supppig#
############

addiptables()
{
echo 1 > /proc/sys/net/ipv4/ip_forward
echo 2 > /proc/sys/net/ipv4/conf/default/rp_filter
echo 2 > /proc/sys/net/ipv4/conf/all/rp_filter
echo 1 > /proc/sys/net/ipv4/conf/all/send_redirects

if [ "$gxzfms" = "2" ];then
gxzf="DNAT --to-destination $gxwgip:"
else
gxzf="REDIRECT --to-ports "
fi
if [ "$bdzfms" = "2" ];then
bdzf="DNAT --to-destination 127.0.0.1:"
else
bdzf="REDIRECT --to-ports "
fi


#======nat===共享规则
iptables -t nat -N ssr_nat_PRE
sleep 0.1
iptables -t nat -A ssr_nat_PRE ! -s 192.168.0.0/16 -j ACCEPT
iptables -t nat -A ssr_nat_PRE -d 192.168.0.0/16 -j ACCEPT
iptables -t nat -A ssr_nat_PRE -p tcp -j ${gxzf}1230
iptables -t nat -A ssr_nat_PRE -p udp --dport 53 -j ${gxzf}1240
#共享禁udp
if [ "$gxudp" = "0" ];then
iptables -t nat -A ssr_nat_PRE -p udp -j ${gxzf}65535
else
iptables -t nat -A ssr_nat_PRE -p udp -j ACCEPT
fi
iptables -t nat -I PREROUTING -j ssr_nat_PRE
sleep 0.1

#======nat=====本地转发规则
iptables -t nat -N ssr_nat_OUT
sleep 0.1
iptables -t nat -A ssr_nat_OUT ${ssfx} -j ACCEPT
iptables -t nat -A ssr_nat_OUT -o lo -j ACCEPT
if [ "$qjdl" != "1" ];then
iptables -t nat -A ssr_nat_OUT -o wlan+ -j ACCEPT
else
iptables -t nat -A ssr_nat_OUT -p udp --dport 67:68 -j ACCEPT
iptables -t nat -A ssr_nat_OUT -d 224.0.0.0/3 -j ACCEPT
fi
iptables -t nat -A ssr_nat_OUT -o tun+ -j ACCEPT
iptables -t nat -A ssr_nat_OUT -o ap+ -j ACCEPT
#tcp直连uid
for x in $tfx;   
do
  if [ "$x" != "" ];then iptables -t nat -A ssr_nat_OUT -p tcp -m owner --uid-owner $x -j ACCEPT;fi
done
#udp放行uid
for x in $ufx;   
do
  if [ "$x" != "" ];then iptables -t nat -A ssr_nat_OUT -p udp -m owner --uid-owner $x -j ACCEPT;fi
done
#udp禁网uid
for x in $ujw;   
do
  if [ "$x" != "" ];then iptables -t nat -A ssr_nat_OUT -p udp -m owner --uid-owner $x -j ${bdzf}65535;fi
done
#彩信
if [ "$cxfx" = "1" ];then
iptables -t nat -A ssr_nat_OUT -d 10.0.0.172/32 -j ACCEPT 
elif [ "$cxfx" = "2" ];then
iptables -t nat -A ssr_nat_OUT -d 10.0.0.200/32 -j ACCEPT
fi
iptables -t nat -A ssr_nat_OUT -p tcp -j ${bdzf}1230
iptables -t nat -A ssr_nat_OUT -p udp --dport 53 -j ${bdzf}1240
#本机禁网udp
if [ "$bjudp" = "0" ];then
  iptables -t nat -A ssr_nat_OUT -p udp -j ${bdzf}65535
else
  iptables -t nat -A ssr_nat_OUT -p udp -j ACCEPT
fi
iptables -t nat -I OUTPUT -j ssr_nat_OUT
sleep 0.1


if [ "$dludp" = "1" -o "$dludp" = "2" ];then
#======mangle=======
#======LAN地址表====
iptables -t mangle -N SSR_UDP_LAN
sleep 0.1
iptables -t mangle -A SSR_UDP_LAN -d 127.0.0.0/8 -j ACCEPT 
iptables -t mangle -A SSR_UDP_LAN -d 192.168.0.0/16 -j ACCEPT
iptables -t mangle -A SSR_UDP_LAN -d 10.0.0.0/8 -j ACCEPT
iptables -t mangle -A SSR_UDP_LAN -d $ip -j ACCEPT
iptables -t mangle -A SSR_UDP_LAN -d 224.0.0.0/3 -j ACCEPT
iptables -t mangle -A SSR_UDP_LAN -d 0.0.0.0/8 -j ACCEPT
iptables -t mangle -A SSR_UDP_LAN -d 172.16.0.0/12 -j ACCEPT
iptables -t mangle -A SSR_UDP_LAN -d 100.64.0.0/10 -j ACCEPT
iptables -t mangle -A SSR_UDP_LAN -d 169.254.0.0/16 -j ACCEPT

#====PREROUTING=====
iptables -t mangle -N SSR_UDP_PRE 
sleep 0.1
iptables -t mangle -A SSR_UDP_PRE -j SSR_UDP_LAN
iptables -t mangle -A SSR_UDP_PRE -p udp -j TPROXY --on-port ${zfudpport} --tproxy-mark 0x6688

sleep 0.1
testtproxy=$(iptables -t mangle -S SSR_UDP_PRE | grep -i TPROXY)
if [ -z "$testtproxy" ];then
killprocess
deliptables
rm -f *.conf
echo ""
echo "唉。。呃。。。这应该怎么说好呢。。:("
echo ""
echo "你的手机系统，貌似不支持TPROXY模块啊~~~"
echo "所以嘛。。UDP转发就不支持啦~~~"
echo "把setting.ini里面的“UDP代理方式”改成0，再启动吧~"
echo "  脚本版免UDP，是没戏了~~~"
echo ""
exit 0
fi

iptables -t mangle -I PREROUTING -p udp -j SSR_UDP_PRE
sleep 0.1

#=====OUTPUT=======
iptables -t mangle -N SSR_UDP_OUT
sleep 0.2
iptables -t mangle -A SSR_UDP_OUT ${ssfx} -j ACCEPT
iptables -t mangle -A SSR_UDP_OUT -j SSR_UDP_LAN
if [ "$qjdl" != "1" ];then
iptables -t mangle -A SSR_UDP_OUT -o wlan+ -j ACCEPT
fi
#udp代理例外UID
for x in $udplwuid;   
do
if [ "$x" != "" ];then
if [ "$udpdlgz" = "0" ];then 
iptables -t mangle -A SSR_UDP_OUT -m owner --uid-owner $x -j ACCEPT
else
iptables -t mangle -A SSR_UDP_OUT -m owner --uid-owner $x -j MARK --set-mark 0x6688
fi
fi
done
iptables -t mangle -A SSR_UDP_OUT -p udp --dport 53 -j ACCEPT
if [ "$udpdlgz" = "0" ];then
iptables -t mangle -A SSR_UDP_OUT -p udp -j MARK --set-mark 0x6688
else
iptables -t mangle -A SSR_UDP_OUT -j ACCEPT
fi
iptables -t mangle -I OUTPUT -p udp -j SSR_UDP_OUT
sleep 0.1

ip rule add fwmark 0x6688 table 251
ip route add local 0.0.0.0/0 dev lo table 251
sleep 0.1
fi

}

deliptables()
{
iptables -t nat -D PREROUTING -j ssr_nat_PRE 2>&-
iptables -t nat -D OUTPUT -j ssr_nat_OUT 2>&-
sleep 0.1
iptables -t nat -F ssr_nat_PRE 2>&-
iptables -t nat -F ssr_nat_OUT 2>&-
iptables -t nat -X ssr_nat_PRE 2>&-
iptables -t nat -X ssr_nat_OUT 2>&-

iptables -t mangle -D PREROUTING -p udp -j SSR_UDP_PRE 2>&-
iptables -t mangle -D OUTPUT -p udp -j SSR_UDP_OUT 2>&-
sleep 0.1
iptables -t mangle -F SSR_UDP_PRE 2>&-
iptables -t mangle -F SSR_UDP_OUT 2>&-
iptables -t mangle -F SSR_UDP_LAN 2>&-
iptables -t mangle -X SSR_UDP_PRE 2>&-
iptables -t mangle -X SSR_UDP_OUT 2>&-
iptables -t mangle -X SSR_UDP_LAN 2>&-
sleep 0.1
ip rule del fwmark 0x6688 table 251 2>&-
ip route del local 0.0.0.0/0 dev lo table 251 2>&-
sleep 0.1
}

killprocess()
{
y=0;z=2
for i in `ps|grep -E "ss-local|ss-tunnel|pdnsd|redsocks|ss-redir|gost"`
do
	((y++))&&[ $y -eq $z ]&&z=$((z+9))&&kill $i 2>&-
done
}

getvpsip_ping()
{
isip=$(echo $ip | grep '[a-z]')
if [ "$isip" != "" ];then
isip=$(ping -c1 -w1 -W1 $ip | grep 'PING' 2>&- | cut -d'(' -f2 |  cut -d')' -f1)
checkip=$(echo "$isip" | grep '\([0-9]\{1,3\}\.\)\{3\}[0-9]\{1,3\}')
if [ "$isip" != "" -a "$isip" = "$checkip" ];then
ip=$isip
jxjg="ping解析IP地址：$ip\n"
else
jxjg="ping解析IP失败！($isip)\n"
fi
fi
}

getvpsip_curl()
{
isip=$(echo $ip | grep '[a-z]')
if [ "$isip" != "" ];then
isip=$(curl --connect-timeout 2 -m 2 -o- http://119.29.29.29/d?dn=$ip 2>&- | cut -d';' -f1)
checkip=$(echo "$isip" | grep '\([0-9]\{1,3\}\.\)\{3\}[0-9]\{1,3\}')
if [ "$isip" != "" -a "$isip" = "$checkip" ];then
ip=$isip
jxjg=$jxjg"curl解析IP地址：$ip\n"
else
jxjg=$jxjg"curl解析IP失败！($isip)\n"
fi
fi
}

make_pdnsd_conf()
{
rm -f pdnsd.cache
cp -f pdnsd.supppig pdnsd.cache
chown root pdnsd.cache
chmod 777 pdnsd.cache

echo "global {
perm_cache=2048;
cache_dir=\"$DIR\";
server_ip=0.0.0.0;
server_port=1240;
query_method=tcp_only;
tcp_qtimeout=20;
timeout=20;
min_ttl=10800;
max_ttl=86400;
daemon=on;
debug=off;
verbosity=0;
neg_rrs_pol=on;
run_as=root;
}
rr {
name=localhost;
reverse=on;
a=127.0.0.1;
owner=localhost;
soa=localhost,root.localhost,42,86400,900,86400,86400;
}">pdnsd.conf

if [ "$dqhost" = "1" ];then
echo "source { 
owner=localhost; 
file=\"/etc/hosts\"; 
} " >>pdnsd.conf
fi

ll=0
for x in $dns; 
do
 if [ "$x" != "" ];then
 ((ll++))
 echo "server {
label=\"supppig$ll\";
ip=$x;
port=53;
uptest=none;
edns_query=off;
proxy_only=on;
}" >>pdnsd.conf
 fi
done
}

make_ssconf()
{
echo "{
\"server\": \"$ip\", 
\"server_port\": $1,
\"password\": \"$password\", 
\"method\":\"$method\", 
\"protocol\": \"$protocol\", 
\"protocol_param\": \"$protocol_param\",
\"obfs\": \"$obfs\", 
\"obfs_param\": \"$host\"
}" > $2
}

datacontrol()
{
if [ "$netstat" != "$1" -a "$cqwl" = "1" ];then
wifiip=$(ifconfig wlan0 2>&- | grep 'inet addr')
if [ "$wifiip" = "" ];then
[ "$1" = "y" ] && sleep 0.3 && svc data enable
[ "$1" = "n" ] && svc data disable && sleep 0.3
netstat="$1"
fi
fi
}

mount -o remount,rw -t auto /data
cd "${0%/*}"
. ./setting.ini
killprocess
deliptables
if [ "$1" = "S" ];then
exit 0
fi
sleep 0.5

#获取IP
if [ "$ymzh" = "1" ];then
getvpsip_ping
getvpsip_curl
fi

#IP地址获取成功，则关网
isip=$(echo $ip | grep '[a-z]')
if [ "$isip" = "" ];then
datacontrol n
fi

if [ "$dludp" = "1" ];then
runas="root" && ssfx="-d $ip -m owner --uid-owner $runas"
if [ -z "$udpport" -o "$udpport" = "$port" ];then
udpport=$port sswithu="-u " zfudpport=1230
else
zfudpport=1231
fi
else
runas="net_raw" && ssfx="-m owner --uid-owner $runas"
fi

[ "$dludp" = "2" ] && zfudpport=1250 && [ -z "$udpport" ] && udpport="6688"

hz="" && [ "$pbq" = "1" ] && hz="-video" && dns="158.69.209.100 45.32.72.192 45.63.69.42"

make_ssconf ${port} "ss.conf"
make_pdnsd_conf

#===UDP over TCP====
if [ "$dludp" = "2" ];then
#redsocks2配置文件  1250
echo "
base {
 log_debug = off;
 log_info = off;
 log = stderr;
 daemon = on;
 redirector = iptables;
}

redudp {
 local_ip = 0.0.0.0;
 local_port = 1250;
 ip = 127.0.0.1;
 port = 1251;
 type = socks5;
 udp_timeout = 20;
}
">redsocks.conf

#gost配置文件  1251
[ "$gostip" = "" ] && gostip=$ip
echo "
{
    \"ServeNodes\": [
        \"socks://127.0.0.1:1251\"
    ],
    \"ChainNodes\": [
        \"socks://127.0.0.1:1252\",
        \"socks://supppig:${gostpwd}@${gostip}:${udpport}\"
    ]
}
" >gost.conf
sleep 0.1
nohup ./ss-local -b 127.0.0.1 -l 1252 -c ss.conf -t 180 -a ${runas} >/dev/null &
nohup ./gost -C gost.conf >/dev/null &
./redsocks2 -c redsocks.conf >/dev/null &
fi
sleep 0.1

nohup ./ss-redir${hz} -b 0.0.0.0 -l 1230 -c ./ss.conf -t 7200 -a ${runas} ${sswithu} >/dev/null &
if [ "$dludp" = "1" -a -z "$sswithu" ];then
make_ssconf ${udpport} "ss1.conf"
nohup ./ss-redir -b 0.0.0.0 -l 1231 -c ss1.conf -t 180 -a ${runas} -U >/dev/null &
fi
./pdnsd -c pdnsd.conf >/dev/null &

sleep 0.2
addiptables
rm -f *.conf
sleep 1
. ./check.sh
datacontrol n
datacontrol y





